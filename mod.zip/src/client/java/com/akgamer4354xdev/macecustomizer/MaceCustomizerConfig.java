package com.akgamer4354xdev.macecustomizer;

import dev.isxander.yacl3.api.ConfigCategory;
import dev.isxander.yacl3.api.Option;
import dev.isxander.yacl3.api.OptionDescription;
import dev.isxander.yacl3.api.YetAnotherConfigLib;
import dev.isxander.yacl3.api.controller.ColorControllerBuilder;
import dev.isxander.yacl3.api.controller.IntegerSliderControllerBuilder;
import java.awt.Color;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public final class MaceCustomizerConfig {
    private static int maceTextureLevel = 3;
    private static int maceColor = 0xFFFFFF;
    private static int maceVisualTransitionTicks = 5;

    private MaceCustomizerConfig() {
    }

    public static int getMaceTextureLevel() {
        return maceTextureLevel;
    }

    public static int getMaceColor() {
        return maceColor;
    }

    public static int getMaceVisualTransitionTicks() {
        return maceVisualTransitionTicks;
    }

    public static Screen createScreen(Screen parent) {
        return YetAnotherConfigLib.createBuilder()
            .title(Text.literal("Mace Customizer"))
            .category(ConfigCategory.createBuilder()
                .name(Text.literal("Mace Appearance"))
                .option(Option.<Integer>createBuilder()
                    .name(Text.literal("MACE 3D TEXTURE LEVEL"))
                    .description(OptionDescription.of(Text.literal("Controls the cosmetic depth of the mace model.")))
                    .binding(3, () -> maceTextureLevel, value -> maceTextureLevel = value)
                    .controller(option -> IntegerSliderControllerBuilder.create(option).range(1, 10).step(1))
                    .build())
                .option(Option.<Color>createBuilder()
                    .name(Text.literal("MACE COLOR"))
                    .description(OptionDescription.of(Text.literal("The cosmetic tint used for custom mace rendering.")))
                    .binding(new Color(0xFFFFFF), () -> new Color(maceColor), value -> maceColor = value.getRGB() & 0xFFFFFF)
                    .controller(ColorControllerBuilder::create)
                    .build())
                .option(Option.<Integer>createBuilder()
                    .name(Text.literal("MACE VISUAL TRANSITION TICKS"))
                    .description(OptionDescription.of(Text.literal("Controls the duration of cosmetic mace visual transitions.")))
                    .binding(5, () -> maceVisualTransitionTicks, value -> maceVisualTransitionTicks = value)
                    .controller(option -> IntegerSliderControllerBuilder.create(option).range(1, 20).step(1))
                    .build())
                .build())
            .build()
            .generateScreen(parent);
    }
}
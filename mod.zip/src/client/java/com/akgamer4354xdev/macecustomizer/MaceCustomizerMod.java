package com.akgamer4354xdev.macecustomizer;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.item.AxeItem;
import net.minecraft.item.MaceItem;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public final class MaceCustomizerMod implements ClientModInitializer {
    public static final String MOD_ID = "macecustomizer";
    public static boolean isMasterEnabled = true;

    private static final KeyBinding.Category KEY_CATEGORY = KeyBinding.Category.create(
        Identifier.of(MOD_ID, "main")
    );
    private static final KeyBinding TOGGLE_3D_MACE = KeyBindingHelper.registerKeyBinding(new KeyBinding(
        "key.macecustomizer.toggle_3d_mace",
        InputUtil.Type.KEYSYM,
        GLFW.GLFW_KEY_UNKNOWN,
        KEY_CATEGORY
    ));

    // Combo Macro Variables
    private static int backTimer = 0;
    private static boolean awaitingBack = false;
    private static int originalSlot = -1;

    @Override
    public void onInitializeClient() {
        // Register Toggle Key
        ClientTickEvents.END_CLIENT_TICK.register(this::handleToggleKey);
        
        // Register Our Custom Stun Slam Mechanic
        registerCustomMechanic();
    }

    private void handleToggleKey(MinecraftClient client) {
        while (TOGGLE_3D_MACE.wasPressed()) {
            isMasterEnabled = !isMasterEnabled;
            if (client.player != null) {
                client.player.sendMessage(
                    Text.literal("Mace Customizer: " + (isMasterEnabled ? "ON" : "OFF"))
                        .formatted(isMasterEnabled ? Formatting.GREEN : Formatting.RED),
                    true
                );
            }
        }
    }

    public static void registerCustomMechanic() {
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (!isMasterEnabled || client.player == null || hand != Hand.MAIN_HAND) return ActionResult.PASS;

            if (client.player.getMainHandStack().getItem() instanceof AxeItem) {
                int maceSlot = -1;
                for (int i = 0; i < 9; i++) {
                    if (client.player.getInventory().getStack(i).getItem() instanceof MaceItem) {
                        maceSlot = i;
                        break;
                    }
                }
                if (maceSlot != -1) {
                    originalSlot = client.player.getInventory().selectedSlot;
                    
                    // AUTO-SWAP to Mace
                    client.player.getInventory().selectedSlot = maceSlot;
                    
                    // AUTO-ATTACK with Mace
                    client.interactionManager.attackEntity(client.player, entity);
                    client.player.swingHand(Hand.MAIN_HAND);
                    
                    awaitingBack = true;
                    // Setting se tick delay uthana
                    backTimer = MaceCustomizerConfig.getMaceVisualTransitionTicks(); 
                }
            }
            return ActionResult.PASS;
        });

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (awaitingBack && client.player != null) {
                if (backTimer > 0) {
                    backTimer--;
                } else {
                    client.player.getInventory().selectedSlot = originalSlot;
                    awaitingBack = false;
                }
            }
        });
    }
}
